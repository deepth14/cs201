package scope.more;

public class ddd {
    public static void main(String[] args) {
        String x="add employee";
        System.out.println(x.substring(4,7));
    }
}
